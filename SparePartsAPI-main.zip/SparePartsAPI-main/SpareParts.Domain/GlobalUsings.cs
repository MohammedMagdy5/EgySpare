// Global using directives

global using System.ComponentModel.DataAnnotations;