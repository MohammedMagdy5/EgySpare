﻿namespace SpareParts.Domain;
public interface IMapperProfile
{

}