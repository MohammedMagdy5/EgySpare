﻿namespace SpareParts.Domain;

public interface IDtos
{

}
public class CreateDto : IDtos
{

}
public class ReadDto : IDtos
{

}
public class UpdateDto : IDtos
{

}