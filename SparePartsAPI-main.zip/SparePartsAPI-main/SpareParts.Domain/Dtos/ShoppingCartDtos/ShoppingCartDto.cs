﻿namespace SpareParts.Domain
{
    public class ShoppingCartDto
    {

    }
}