﻿namespace SpareParts.API.Services.Stripe
{
    public class StripeSettings
    {
        public string SecretKey { get; set; } = String.Empty;
        public string Publishablekey { get; set; } = String.Empty;
    }
}