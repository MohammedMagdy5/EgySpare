﻿
namespace SpareParts.Data;
    public interface IOrderForDetailRepo : IRepo<OrderDetail, Guid>
    {
    }
