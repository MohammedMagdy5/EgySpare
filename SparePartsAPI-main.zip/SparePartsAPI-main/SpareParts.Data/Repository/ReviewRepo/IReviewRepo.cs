﻿

namespace SpareParts.Data
{
    public interface IReviewRepo : IRepo<Review, Guid>
    {
    }
}