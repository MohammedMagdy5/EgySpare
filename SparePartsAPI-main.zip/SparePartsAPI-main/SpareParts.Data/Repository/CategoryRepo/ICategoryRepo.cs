﻿
namespace SpareParts.Data
{
    public interface ICategoryRepo : IRepo<Category, int>
    {
    }
}