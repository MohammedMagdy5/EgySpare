﻿

namespace SpareParts.Data
{
    public interface IBrandRepo : IRepo<Brand, int>
    {
    }
}