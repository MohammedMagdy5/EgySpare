﻿

namespace SpareParts.Data
{
    public interface IProductRepo : IRepo<Product, Guid>
    {
    }
}